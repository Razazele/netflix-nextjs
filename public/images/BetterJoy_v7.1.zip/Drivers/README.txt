Driver installer provided for convenience.

Latest ViGEmBus releases are here: https://github.com/ViGEm/ViGEmBus/releases

If you're on Win7, please read the instructions on the page.

HIDGuardian is not installed by default anymore because it caused a lot of users a lot of headaches because they didn't know what to do with it. If you require the drivers for it and know what to do with it (eg: use the controllers with Steam games in Big Picture, if you have a Pro Controller + 2 Joycons), look into the HIDGuardian folder.
Details on using HIDGuardian are on the main README.